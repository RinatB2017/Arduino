

#ifndef _TRINKETHIDCOMBOC_H_
#define _TRINKETHIDCOMBOC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern char usb_hasCommed;
extern uint8_t led_state;
extern uint8_t report_buffer[8];

void usbBegin();
void usbPollWrapper();
void usbReportSend(uint8_t sz);

#define REPID_MOUSE         1
#define REPID_KEYBOARD      2
#define REPID_MMKEY         3
#define REPID_SYSCTRLKEY    4
#define REPSIZE_MOUSE       4
#define REPSIZE_KEYBOARD    8
#define REPSIZE_MMKEY       3
#define REPSIZE_SYSCTRLKEY  2

#ifdef __cplusplus
}
#endif

#endif