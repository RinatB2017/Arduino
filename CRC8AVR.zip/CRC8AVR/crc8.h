#ifndef CRC8_H
#define CRC8_H
#define poly 0x07
unsigned char crc8(unsigned char crc, unsigned char data);
unsigned char crc8_ccitt_block(const unsigned char *data, int length);

#endif