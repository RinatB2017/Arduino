#include "crc8.h"

unsigned char crc8(unsigned char crc, unsigned char data)
{
 crc ^= data;
 int i;
 for (i = 0; i < 8; ++i)
 {crc = (crc << 1) ^ ((crc & 0x80) ? poly : 0);}

 return crc;
}

unsigned char crc8_ccitt_block(const unsigned char *data, int length)
{
 unsigned char crc;
 for (int i = 0; i < length; ++i){
 crc = crc8(crc, data[i]);}

 return crc;
}