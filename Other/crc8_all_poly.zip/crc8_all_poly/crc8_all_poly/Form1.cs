﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApplication1
{
    public enum CRC8_POLY
    {
        CRC8 = 0xd5,
        CRC8_CCITT = 0x07,
        CRC8_DALLAS_MAXIM = 0x31,
        CRC8_SAE_J1850 = 0x1D,
        CRC_8_WCDMA = 0x9b,
    };
    public partial class Form1 : Form
    {
    SerialPort sp = new SerialPort();
    public Form1()
    {
    InitializeComponent();
    }
    
    private void button1_Click(object sender, EventArgs e)
    {
        byte checksum;
        byte t = 255;   
        byte[] testVal = new byte[]{t};
        CRC8Calc crc = new CRC8Calc(CRC8_POLY.CRC8_CCITT);
        checksum = crc.Checksum(testVal);
        //MessageBox.Show(checksum.ToString());
        byte[] data_send=new byte[]{t, checksum};
        sp.Write(data_send, 0, data_send.Length);
    }
    private void button2_Click(object sender, EventArgs e)
    {
        if (!sp.IsOpen)
        {
            sp.BaudRate = 9600;
            sp.DataBits = 8;
            sp.StopBits = StopBits.One;
            sp.Parity = Parity.None;
            sp.PortName = "COM6";
            sp.Handshake = Handshake.None;
            //sp.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived);
            sp.ReadTimeout = 500;
            sp.WriteTimeout = 500;
            sp.Open();
        }
        else
        {
            sp.Close();
        }
    }
    

    private void button3_Click(object sender, EventArgs e)
    {
        
        sp.Close();
    }

    private void button4_Click(object sender, EventArgs e)
    {
      //  MessageBox.Show(t.ToString());
        sp.Write("a");
        //sp.Write(t.ToString());
    }
	
    }
    
    public class CRC8Calc
    {
        private byte[] table = new byte[256];

        public byte Checksum(params byte[] val)
        {
            if (val == null)
                throw new ArgumentNullException("val");

            byte c = 0;

            foreach (byte b in val)
            {
                c = table[c ^ b];
            }

            return c;
        }

        public byte[] Table
        {
            get
            {
                return this.table;
            }
            set
            {
                this.table = value;
            }
        }

        public byte[] GenerateTable(CRC8_POLY polynomial)
        {
            byte[] csTable = new byte[256];

            for (int i = 0; i < 256; ++i)
            {
                int curr = i;

                for (int j = 0; j < 8; ++j)
                {
                    if ((curr & 0x80) != 0)
                    {
                        curr = (curr << 1) ^ (int)polynomial;
                    }
                    else
                    {
                        curr <<= 1;
                    }
                }

                csTable[i] = (byte)curr;
            }

            return csTable;
        }

        public CRC8Calc(CRC8_POLY polynomial)
        {
            this.table = this.GenerateTable(polynomial);
        }
    }
        
}
